package fciencias.icc.practica5;

public class Main {
    public static void main(String[] args) {        
        //Prueba tu implementacion aqui
        //lista vacia de patos
        Lista lista = new Lista();

        //Patos que se usaran para la lista
        Pato c1 = new Pato("Charles", 1, "Blanco");
        Pato c2 = new Pato("Mantequilla", 0, "Amarillo");
        Pato c3 = new Pato("Alan", 19, "Blanco");

        //Agregamos dos patos a la lista
        lista.agregar(c1, 0);
        lista.agregar(c2, 1);

        System.out.println("Implementacion de listas con una lista de patos \nNuestra lista actual es la siguiente: \n");

        //Muestra la lista actual
        lista.muestra();

        //Muestra si la lista esta vacia o no
        System.out.println("¿La lista esta vacia? "+lista.esVacia()+"\n");

        //Muestra la longitud de la lista actual
        System.out.println("La longitud de la lista es: " +lista.getLongitud()+"\n"); 

        //Crea una copia de la lista original y la muestra
        Lista copia = lista.copia();
        System.out.println("Aca tienes una copia de tu lista: ");
        copia.muestra();

        //Pone en reversa a la lista original y la muestra
        lista = lista.reversa();
        System.out.println("La lista original en reversa es: ");
        lista.muestra();

        //Crea una copia de la lista original en reversa 
        Lista copiaR = lista.copia();
        System.out.println("Aca tienes una copia de tu lista en reversa: ");
        copiaR.muestra();

        //Pone los elementos de la lista original en su posicion inicial 
        lista = lista.reversa();
        System.out.println("La lista original ha sido revertida de nuevo, se muestra a continuacion: ");
        lista.muestra();

        //Muestra el pato en la posicion 1 en la lista original y en la copia de la lista en reversa
        System.out.println("El pato que esta en la posicion 1 de la lista original es: \n"+lista.getElemento(1)+"\n");
        System.out.println("El pato que esta en la posicion 1 de la lista reversa es: \n"+copiaR.getElemento(1)+"\n");

        //Muestra en que lugar de la lista original estan ambos patos
        System.out.println("El pato 'Mantequilla' esta en la posicion numero: " +lista.indiceDe(c2)+" de la lista original\n");
        System.out.println("El pato 'Charles' esta en la posicion numero: " +lista.indiceDe(c1)+" de la lista original\n");

        //Agrega un pato a la lista original y muestra sus cambios
        lista.agregar(c3, 2);
        System.out.println("Se acaba de agregar un nuevo pato a la lista original, por tanto, la lista cambio y te la muestro  a continuacion: ");
        lista.muestra();
        System.out.println("La nueva longitud de la lista original es: " +lista.getLongitud()+"\n");

        //Muestra en que lugar de la lista original se encuentra 'Alan'
        System.out.println("El pato 'Alan' esta en la posicion numero: " +lista.indiceDe(c3)+" de la lista original\n");

        //Muestra el pato en la posicion 2 de la lista original
        System.out.println("El pato que esta en la posicion 2 de la lista original es: \n"+lista.getElemento(2)+"\n");

        //Elimina a un pato de cada lista y muestra cual fue
        System.out.println("Un pato  diferente de cada lista decidio irse porque estaban muy pequeñas. \nEn la lista original se fue: \n"+lista.eliminar(2)+"\n");
        System.out.println("En la copia de la primer lista se fue: \n"+copia.eliminar(1)+"\n");
        System.out.println("En la copia de la lista en reversa se fue: \n"+copiaR.eliminar(1)+"\n");

        //Pone en reversa nuevamente a la lista original y la muestra
        lista = lista.reversa();
        System.out.println("Debido a que se fue 'Alan' la lista original se volvio a poner en reversa, quedando asi: ");
        lista.muestra();

        //Saca otra copia de la lista original en su estado actual y la muestra
        Lista copia2 = lista.copia();
        System.out.println("Se acaba de sacar otra copia de la lista original: ");
        copia2.muestra();


        //Elimina a un pato en especifico de la lista copia y en la copia de la lista reversa
        System.out.println("Debido a que 'Mantequilla' ya no esta en la lista copia, y 'Charles' en la copia de la lista en reversa, un pato se decidio salir de cada una de esas listas. \nEn la lista copia se fue: \n"+copia.eliminar(c1)+"\n");
        System.out.println("En la copia de la lista reversa se fue: \n"+copiaR.eliminar(c2));

        //Elimina a 'Mantequilla' de la lista original
        System.out.println("\nPor alguna extraña razon, un pato fue eliminado de la lista original, ese pato fue: \n"+lista.eliminar(c2)+"\n");

        //Muestra el estado actual de todas las listas despues de todos los  cambios anteriores
        System.out.println("Las listas actuales son las siguientes: \nLista Original:");
        lista.muestra();
        System.out.println("Primer copia de la lista: ");
        copia.muestra();
        System.out.println("\nCopia de la lista en reversa:");
        copiaR.muestra();
        System.out.println("\nSegunda copia de la lista");
        copia2.muestra();

        //Creamos nuevos patos para cambiarlos en las listas
        Pato reemplazo = new Pato("Carlos", 10, "Negro");
        Pato reemplazo2 = new Pato("Karla", 0, "Rosa");
        Pato reemplazo3 = new Pato("Alan Jr", 0, "Gris");

        //cambia los patos de la segunda copia por otros nuevos y muestra la segunda copia
        copia2.cambiar(reemplazo, 0);
        copia2.cambiar(reemplazo2, 0);
        System.out.println("Como la segunda copia traia malos recuerdos, se opto por reemplazar todos sus patos por otros, quedando asi la segunda copia:");
        copia2.muestra();
        
        //Cambia a 'Charles' de la lista original por 'Alan Jr'
        lista.cambiar(reemplazo3, 0);
        System.out.println("De la nada, 'Charles' fue reemplazado por un pato nuevo 'Alan Jr', entonces la lista original queda asi: ");
        lista.muestra();

        //Responde si 'Alan Jr' 'Charles' y 'Mantequilla' estan en la lista original
        System.out.println("¿Aun sigue 'Alan Jr' en la lista original? R: "+lista.contiene(reemplazo3)+"\n");
        System.out.println("¿Aun sigue 'Mantequilla' en la lista original? R: "+lista.contiene(c2)+"\n");
        System.out.println("¿Aun sigue 'Charles' en la lista original? R: "+lista.contiene(c1)+"\n");

        //Hace 3 sublistas de la segunda copia y las muestra en pantalla
        Lista sub1 = copia2.subLista(0, 1);
        Lista sub2 = copia2.subLista(1, 1);
        Lista sub3 = copia2.subLista(0, 0);
        System.out.println("Aqui tienes tres sublistas de la segunda copia:\nSublista 1 ");
        sub1.muestra();
        System.out.println("Sublista 2 ");
        sub2.muestra();
        System.out.println("Sublista 3 ");
        sub3.muestra();

        //Limpia la lista original, dejandola sin elementos, y verifica si esta vaica y su longitud
        System.out.println("Porque los programadores quisieron, se va a vaciar la lista original");
        lista.limpia(); 
        System.out.println("¿La lista original quedo vacia? "+lista.esVacia());
        System.out.println("La longitud de la lista limpia es: " +lista.getLongitud()+"\n"); 
    }
}
