package fciencias.icc.practica5;

public interface TDALista{

//NO OLVIDES CAMBIAR OBJECT POR EL OBJETO DE TU PREFERENCIA

    /**
     * Indica si la lista es vacia
     * @return true si la lista es vacia, false en otro caso
     */
    public boolean esVacia();


    /**
     * Regresa la longitud de la lista
     * @return la longitud de la lista
     */
    public int getLongitud();


    /**
     * Vacia la lista dejandola sin elementos
     * No olvides modificar también la longitud para que sea consistente
     */
    public void limpia(); // 1 punto

    
    /**
     * Regresa una copia de la lista
     * @return la copia de la lista
     */
    public Lista copia(); // 1 punto


    /**
     * Regresa la reversa de la lista
     * @return la reversa de la lista
     */
    public Lista reversa(); // 1 punto



    /**
     * Obtiene el i-esimo elemento de la lista
     * @param posicion la posicion del elemento a obtener
     * @return el i-esimo elemento de la lista
     */
    public Pato getElemento(int posicion); // 1 punto


    /**
     * Regresa el indice del elemento en la lista
     * Puedes usar equals()
     * @param elemento el elemento a buscar el indice
     * @return el indice del elemento
     */
    public int indiceDe(Pato elemento); //1 punto


    /**
     * Agrega el elemento en la i-esima posicion indicada
     * @param elemento el elemento a agregar
     * @param posicion la posicion donde se va agregar el elemento
     */
    public void agregar(Pato elemento, int posicion); // 1 punto


    /**
     * Elimina el elemento en la i-esima posicion indicada
     * Elimina por indice
     * @param posicion la posicion donde se va eliminar el elemento
     * @return el elemento eliminado
     */
    public Pato eliminar(int posicion); // 1 punto


    /**
     * Elimina el elemento en la i-esima posicion indicada
     * Elimina por elemento
     * @param posicion la posicion donde se va eliminar el elemento
     * @return el elemento eliminado
     */
    public Pato eliminar(Pato elemento); // 1 punto


    /**
     * Cambia el elemento que hay en la lista por uno nuevo
     * @param elemento el nuevo elemento
     * @param posicion la posicion donde se va cambiar el elemento
     */
    public void cambiar(Pato elemento, int posicion); // 1 punto


    /**
     * Verifica si el elemento dado esta en la lista
     * Puedes usar equals()
     * @param elemento el elemento a buscar
     * @return true si el elemento esta en la lista, false en otro caso
     */
    public boolean contiene(Pato elemento); // 1 punto


    //- Suma total de los puntos 10


    /*** EXTRA ***/
    /**
     * Regresa una sublista de la lista original
     * @param inicio el incio de la sublista
     * @param fin el fin de la sublista
     * @return la sublista
     */
    public Lista subLista(int inicio, int fin); // + 1

    //- teniendo un total de 11 sobre el 85%

    /**
     * PRO TIP: seria bueno tener un método que busque un nodo en especifico
     * para utilizarlo en otros métodos
     */

}
