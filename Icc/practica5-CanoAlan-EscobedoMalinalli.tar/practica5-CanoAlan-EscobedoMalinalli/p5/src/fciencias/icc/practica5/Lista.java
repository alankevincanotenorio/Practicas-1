package fciencias.icc.practica5;
/**
 *Clase Lista que implementa la interfaz TDALista 
 *@author Alan Kevin Cano Tenorio y Malinalli Escobedo Irineo
 *@version 1.0
 */
public class Lista implements TDALista{

    //NO OLVIDES CAMBIAR OBJECT POR EL OBJETO DE TU PREFERENCIA

        /* El nodo inical */
        private Nodo cabeza;

        /* longitud de la lista */
        private int lista;

        


        //Metodos auxiliares
        private void agregarInicio(Pato otro){
        Nodo nuevo = new Nodo(otro);
        if(esVacia()) cabeza=nuevo;
        else{
        nuevo.setSiguiente(cabeza);
        cabeza=nuevo;
        }
        lista++;
        }

        private void agregafinal(Pato otro){
        Nodo nuevo = new Nodo(otro);
        if(esVacia()) cabeza = nuevo;
        else{
            Nodo aux = cabeza;
        while (aux.getSiguiente() != null) {
            aux = aux.getSiguiente();
        }
        aux.setSiguiente(nuevo);
        }
          lista++;
        }
    

        //Metodos de interfaz

    /**
    * Indica si la lista es vacia
    * @return true si la lista es vacia, false en otro caso
    */
    public boolean esVacia(){
    //Aqui va tu codigo
    return cabeza == null;
    }
    

    /**
    * Regresa la longitud de la lista
    * @return la longitud de la lista
    */
    public int getLongitud(){
    //Aqui va tu codigo
    return lista;
    }

        
    /**
    * Muestra la lista
    */
    public void muestra(){
    if(esVacia())
    System.out.println("La lista esta vacia");
    else{
    Nodo actual=cabeza;
    while(actual!=null) {
    if (actual.getElemento() != null) {
    System.out.println(actual.getElemento()+"\n");
    }
    actual=actual.getSiguiente();
    }
    }
    }
    

     /**
     * Vacia la lista dejandola sin elementos
     * No olvides modificar también la longitud para que sea consistente
     */
    public void limpia(){
    //Aqui va tu codigo
    if(esVacia()) System.out.println("No puedes vaciar la lista debido a que ya estaba vacia");
    else{
    cabeza = null;
    lista = 0;
    System.out.println("Por la magia de la programacion, la lista se vacio");
    }
    }


    /**
     * Regresa una copia de la lista
     * @return la copia de la lista
     */
    public Lista copia(){
        //Aqui va tu codigo
        if(esVacia()){
        System.out.println("No puedes hacer una copia porque la lista esta vacia");
        return null;
        }
        else{
        Lista copia = new Lista();
        Nodo aux = cabeza;
        while (aux != null){
        Pato x = aux.getElemento();
        copia.agregafinal(x);
        aux = aux.getSiguiente();
        }
        return copia;
        }
    }        



    /**
     * Regresa la reversa de la lista
     * @return la reversa de la lista
     */
    public Lista reversa(){
        //Aqui va tu codigo
        Lista reversa = new Lista();
        if (esVacia()){
            System.out.println("No puedes hacer una reversa de la lista porque esta vacia");
            return null;
        }
        else{
            Nodo auxiliar  = cabeza;
            while(auxiliar != null){
            Pato x = auxiliar.getElemento();
            reversa.agregarInicio(x);
            auxiliar = auxiliar.getSiguiente();
            }
        return reversa;
        }
    }


      /**
     * Obtiene el i-esimo elemento de la lista
     * @param posicion la posicion del elemento a obtener
     * @return el i-esimo elemento de la lista
     */
    public Pato getElemento(int posicion) {
    if (posicion < 0 || posicion >= lista) {
        System.out.println("EL indice indicado no está dentro de la lista");
        return null;
    } else {
        Nodo actual = cabeza;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }
        return actual.getElemento();
    }
    }


    /**
     * Regresa el indice del elemento en la lista
     * @param elemento el elemento a buscar el indice
     * @return el indice del elemento
     */
    public int indiceDe(Pato elemento) {
    //Aqui va tu codigo
    Nodo actual = cabeza;
    int indice = 0;
    while (actual != null) {
        if (actual.getElemento().equals(elemento)) {
            return indice;
        }
        actual = actual.getSiguiente();
        indice++;
    }
    return -1;
    }



    /**
     * Agrega el elemento en la i-esima posicion indicada
     * @param elemento el elemento a agregar
     * @param posicion la posicion donde se va agregar el elemento
     */
    public void agregar(Pato elemento, int posicion) {
        //Aqui va tu codigo
        Nodo agregar = new Nodo(elemento);
        if (esVacia() || posicion <= 0) {
            agregarInicio(elemento);
        } else if (posicion > lista) {
            System.out.println("La posición no es válida");
        } else {
            Nodo aux = cabeza;
            for (int i = 0; i < posicion - 1; i++) {
                aux = aux.getSiguiente();
            }
            agregar.setSiguiente(aux.getSiguiente());
            aux.setSiguiente(agregar);
            lista++;
        }
    }
    

    /**
     * Elimina el elemento en la i-esima posicion indicada
     * Elimina por indice
     * @param posicion la posicion donde se va eliminar el elemento
     * @return el elemento eliminado
     */
    public Pato eliminar(int posicion) {
        if (esVacia() || posicion < 0 || posicion > lista-1) {
            System.out.println("No se puede eliminar el pato porque la lista esta vacia o la posicion es invalida");
            return null;
        }
        Nodo aux = cabeza;
        Pato borrado;
        if (posicion == 0) {
            borrado = cabeza.getElemento();
            cabeza = cabeza.getSiguiente();
        } else {
            for (int i = 0; i < posicion - 1; i++) {
                aux = aux.getSiguiente();
            }
            borrado = aux.getSiguiente().getElemento();
            aux.setSiguiente(aux.getSiguiente().getSiguiente());
        }
        lista--;
        return borrado;
    }


    /**
     * Elimina el elemento en la i-esima posicion indicada
     * Elimina por elemento
     * @param posicion la posicion donde se va eliminar el elemento
     * @return el elemento eliminado
     */
    public Pato eliminar( Pato elemento){
        if(!contiene(elemento)){
            System.out.println("No se puede eliminar el pato porque no existe en la lista");
            return null;
        }else if(cabeza.getElemento().equals(elemento)){
            cabeza = cabeza.getSiguiente();
            lista--;
        }else{
        Nodo anterior = cabeza;
        Nodo actual = cabeza.getSiguiente();
            while (actual != null) {
                if (actual.getElemento().equals(elemento)) {
                    anterior.setSiguiente(actual.getSiguiente()); 
                    lista--;
                }
                anterior = actual;
                actual = actual.getSiguiente();
            }
        }
        return elemento;
    }



    /**
     * Cambia el elemento que hay en la lista por uno nuevo
     * @param elemento el nuevo elemento
     * @param posicion la posicion donde se va cambiar el elemento
     */
    public void cambiar(Pato elemento, int posicion){
        if(esVacia()|| posicion <0 || lista-1<posicion)
            System.out.println("No se puede cambiar el pato en esa posicion debido a que no existe");
        else if(posicion == 0){
            cabeza.setElemento(elemento);
        }else{
            Nodo aux = cabeza;
              for(int i=0; i<posicion; i++){
                    if(i==posicion-1){
                        aux.getSiguiente().setElemento(elemento);
                    }
                    aux = aux.getSiguiente();
                }
        }
    }
    

    /**
     * Verifica si el elemento dado esta en la lista
     * Puedes usar equals()
     * @param elemento el elemento a buscar
     * @return true si el elemento esta en la lista, false en otro caso
     */
    public boolean contiene(Pato elemento){
        Nodo aux = cabeza;
        while(aux != null){
            if(aux.getElemento().equals(elemento)){
                return true;
            }
             aux=aux.getSiguiente();
        }
        return false;
    }


    /*** EXTRA ***/
    /**
     * Regresa una sublista de la lista original
     * @param inicio el incio de la sublista
     * @param fin el fin de la sublista
     * @return la sublista
     */
    public Lista subLista(int inicio, int fin){
        if(esVacia() || inicio <0 || fin <0 || inicio>lista-1 || fin>lista-1 || inicio>fin){
         System.out.println("No puedes sacar una sublista porque esos indices son incorrectos y/o la lista esta vacia");   
         return null;
        }
        else{
            Lista sub = new Lista();
            Nodo aux = cabeza;
           for(int i=0; i<inicio  ; i++){
                aux=aux.getSiguiente();
            }
        
            for (int i=inicio; i<=fin; i++) {
                Pato x= aux.getElemento();
                sub.agregafinal(x);
                aux=aux.getSiguiente();
            }        
            return sub;
        }
    }

}
