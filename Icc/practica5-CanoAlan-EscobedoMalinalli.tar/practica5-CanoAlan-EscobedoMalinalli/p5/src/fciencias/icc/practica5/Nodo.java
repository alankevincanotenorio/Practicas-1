package fciencias.icc.practica5;

public class Nodo {
    
    //El elemento que queremos guardar en nuestro nodo
    //no olvides CAMBIAR el tipo Object por el objeto de tu preferencia
    private Pato elemento;

    //el elementos siguiente
    private Nodo siguiente; //null

    public Nodo(Pato elem){
        this.elemento=elem;//queremos que dentro del nodo tenga un objeto x
    }
    //queremos algo como
    //Gatito gatitoJuan = new Gatito();
    //Nodo nuevo = new(gatitoJuan);
    //o--o--o--o--o--o--o--o--o--o--o

    public void setElemento(Pato elemento) {
        this.elemento = elemento;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    public Pato getElemento() {
        return elemento;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }
}