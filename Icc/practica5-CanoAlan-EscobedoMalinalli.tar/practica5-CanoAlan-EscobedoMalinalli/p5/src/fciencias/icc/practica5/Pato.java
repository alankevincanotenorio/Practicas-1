package fciencias.icc.practica5;
/**
 *Clase Pato para crear patos
 *@author Alan Kevin Cano Tenorio y Malinalli Escobedo Irineo
 *@version 1.0
 */
public class Pato {
    
    private String nombre;
    private int edad;
    private String color;

    public Pato (String nombre, int edad, String color){
         this.nombre = nombre;
         this.edad = edad;
         this.color = color;
    }

    public String toString(){
        return "Nombre: " +nombre+"\n"+
        "Edad: "+edad+"\n"+
        "Color: "+color;
    }
}
