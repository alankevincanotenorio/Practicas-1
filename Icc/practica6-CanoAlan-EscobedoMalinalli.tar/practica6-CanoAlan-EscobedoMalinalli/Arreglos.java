/**Clase Arreglos que imlpementa la interfaz InterfazArreglos y que tiene el metodo Main
 * @author Alan Kevin Cano Tenorio y Malinalli Escobedo Irineo
 * @version 1.0
 */
public class Arreglos implements InterfazArreglos{

    public static void main(String[] args){
        //Se crearon diferentes arreglos para mostrar los ejemplos que mandaron en Classroom y mostrar el funcionamiento de los metodos.
        Arreglos m = new Arreglos();
        int[] masRepetido1 ={1,8,4,6,1,3,5,4,1};
        int [] masRepetido2 ={0,8,4,5,7,4,3,5,9,1,4,4}; 
        int[][] espejo1 ={{2,5,0},{7,3,8},{3,0,1}};
        int[][] espejo2 ={{2,5,0},{7,3,8}};
        int[][] espejo3 ={{2,5},{7,3},{3,0}};
        char[][] matrizConstruyeFrase = {{'h', 'o', 'l','a'},{'q', 'u', 'e'},{'t', 'a', 'l'}}; 
        int[] contenedor1 ={8,4,6,2,3,0,5,1};
        int[] contenedor2 ={1,8,4,6,1,3,5,4,1};
        int[] quitarRepetido = {8,4,5,2,2,0,5,8};


        // Muestra la ejecucion del metodo masRepetido
        //ejemplo 1
        int n = m.masRepetido(masRepetido1);
        System.out.print("El numero que se repite más en el arreglo ");
        m.mostrar(masRepetido1);
        System.out.print(" es el numero "+n+"\n");

        //ejemplo2
        int o = m.masRepetido(masRepetido2);
        System.out.print("\nEl numero que se repite más en el arreglo ");
        m.mostrar(masRepetido2);
        System.out.print(" es el numero "+o+"\n");


        // Muestra la ejecucion del metodo matrizEspejo
        //ejemplo 1
        System.out.println("\nTeniendo la siguiente matriz:");
        m.mostrarMatriz(espejo1);
        System.out.println("Su matriz espejo es:");
        int[][] matrizEspejo = m.matrizEspejo(espejo1);
        m.mostrarMatriz(matrizEspejo);

        //ejemplo 2
        System.out.println("\nTeniendo la siguiente matriz:");
        m.mostrarMatriz(espejo2);
        System.out.println("Su matriz espejo es:");
        int[][] matrizEspejo2 = m.matrizEspejo(espejo2);
        m.mostrarMatriz(matrizEspejo2);

        //ejemplo 3
        System.out.println("\nTeniendo la siguiente matriz:");
        m.mostrarMatriz(espejo3);
        System.out.println("Su matriz espejo es:");
        int[][] matrizEspejo3 = m.matrizEspejo(espejo3);
        m.mostrarMatriz(matrizEspejo3);


        // Muestra la ejecucion del metodo construyeFrase
        System.out.println("\nA partir de la siguiente matriz:");
        //Muestra la matriz de caracteres
        for (int i = 0; i < matrizConstruyeFrase.length; i++) {
            System.out.print("[");
            for (int j = 0; j < matrizConstruyeFrase[i].length; j++) {
                System.out.print(matrizConstruyeFrase[i][j]);
                if (j < matrizConstruyeFrase[i].length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]");
        }
        System.out.println("Se construye la siguiente frase: "+m.construyeFrase(matrizConstruyeFrase));
        

        // Muestra la ejecucion del metodo contenido
        //ejemplo 1
        int [] contenidoEn = {5,4,1};
        System.out.print("\n¿El arreglo ");
        m.mostrar(contenidoEn);
        System.out.print(" esta contenido en el arreglo ");
        m.mostrar(contenedor1);
        System.out.println("? R: "+m.contenido(contenidoEn, contenedor1));

        //ejemplo 2
        int [] contenidoEn2 = {0,0};
        System.out.print("\n¿El arreglo ");
        m.mostrar(contenidoEn2);
        System.out.print(" esta contenido en el arreglo ");
        m.mostrar(contenedor2);
        System.out.println("? R: "+m.contenido(contenidoEn2, contenedor2));

        
        // Muestra la ejecucion del metodo quitaRepetidos
        System.out.print("\nDado el arreglo ");
        m.mostrar(quitarRepetido);
        System.out.print(" y quitando los valores repetidos tenemos el arreglo");
        int[] quitaRepetidos = m.quitaRepetidos(quitarRepetido);
        m.mostrar(quitaRepetidos);
        

        // Muestra la ejecucion del metodo pascal
        int nivel = 4;
        System.out.println("\nEl triangulo de pascal de nivel "+nivel+" es el siguiente:");
        m.pascal(nivel);
    
    }
    

    //Implementacion de metodos de la interfaz y auxiliares

    /**
     * Encuentra el número más repetido dentro de un arreglo.
     * @param numeros un arreglo de numeros enteros.
     * @return el entero más repetido del arreglo.
     */
    public int masRepetido(int[] numeros){
        int repF =0; //guarda el numero de repeticiones de un numero
        for(int i=0; i<numeros.length; i++){ //recorremos el arrelo
            int contadorA=0;
            int contadorF =0;
            int repA= numeros[i];
            for(int j=i+1; j<numeros.length; j++){ //recorremos el arreglo
                if(numeros[j] == repA){
                    contadorA++;
                }
            }
            if(contadorA>contadorF){
                contadorF=contadorA;
                repF=repA;
            }
        }
        return repF;
    }
    

    /**
     * Regresa el espejo de una matriz.
     * @param arreglo el arreglo a calcular su espejo.
     * @return Un arreglo con la representación de la
     * matriz espejo del parámetro.
     */
    public int[][] matrizEspejo(int[][] arreglo){
        int [][] arr = new int [arreglo.length][arreglo[0].length]; //esta guarda la matriz espejo
        for(int i=0; i<arreglo.length; i++){    //recorremos la matriz
            int a=0;
            for(int j=arreglo[0].length-1;j>-1; j--){ //recorre una parte de la matrz
                arr[i][j] = arreglo[i][a];
                a++;
            }
        }
        return arr;
    }


    /**
     * Crea una cadena a partir de un arreglo bidimensional de caracteres
     * Cada subarreglo será una palabra en la frase.
     * Cada palabra estará separada por un espacio.
     * @param frase el arreglo con la frase.
     * @return la frase formada a partir de caracteres.
     */
    public String construyeFrase(char[][] frase){
        String fras ="";    //creamos una cadena para almacenar la frase
        for(int i=0; i<frase.length; i++){ //recorremos la matriz
            for(int j=0; j<frase[i].length; j++){ //recorre una parte de la matriz
                fras += frase[i][j];
            }
            fras+=" ";
        }
        return fras;
    }


    /**                                                                                                 
     * Permite saber si todos los elementos de un arreglo están contenidos en otro.                     
     * @param contenido un arreglo de numeros enteros                                                   
     * @param contenedor un arreglo donde verificar si el arreglo                                       
     * contiene todos los elementos de contenido.                                                       
     * @return true si contiene todos los elementos, false en otro caso.                                
     */
    public boolean contenido(int[] contenido, int[] contenedor){
        Arreglos m = new Arreglos(); //permite mandar a llamar el metodo aux
        for(int i=0; i<contenido.length; i++){ //recorremos el arreglo contenido
            boolean bandera=true;
            int x = contenido[i];
            for(int j=0; j<contenedor.length; j++){      //recorremos el arreglo contenedor
                if(contenedor[j]==x){
                   contenedor = m.aux(contenedor, x); //mandamos a llamar el metodo aux
                   bandera=false; 
                   break;
                }
            }
            if(bandera) return false;
        }
        return true;
    }


    /**                                                                                                 
     * Elimina un numero del arreglo si este lo encuentra, es util para el metodo contendio
     * ya que, asi se descarta la comparacion repetitiva de un numero
     * @param arreglo un arreglo de numeros enteros                                                   
     * @param x el entero a eliminar en caso que se encuentre                                   
     * @return un arreglo de enteros sin el entero que recibe                               
     */
    private int[] aux(int[] arreglo, int x) {
        int[] arr = new int[arreglo.length-1]; //guarda el arreglo con el numero x eliminado
        boolean eliminado=false;
        for (int i=0, j=0; i<arreglo.length; i++) { //recorre el arreglo
            if(arreglo[i]==x && !eliminado){
                eliminado = true;
            }else{
                arr[j++]=arreglo[i];
            }
        }
        return arr;
    }

   
    /**
    * Elimina los elementos repetidos de un arreglo.
    * @param arreglo el arreglo del cual eliminar repetidos.
    * @return un arreglo sin elementos repetidos.
    */
    public int[] quitaRepetidos(int[] arreglo) {
        int[] arr = new int[arreglo.length]; 
        int m = 0; 
         for (int i=0; i < arreglo.length; i++) { //recorre el arreglo
            boolean esRepetido = false;
            for (int j=0; j<m; j++) {
                 if (arreglo[i]==arr[j]) {
                    esRepetido=true;
                    break;
                }
            }
            if (!esRepetido) {
                arr[m]=arreglo[i];
                 m++;
            }
        }
        int[] arrF=new int[m]; //guarda el arreglo sin numeros repetidos
         for(int i=0; i<m; i++){
            arrF[i]=arr[i];
        }
        return arrF;
    }
    

    /**
     * Construye tantos niveles del triángulo de Pascal como se soliciten.
     * @param n la cantidad de niveles del triangulo a construir.
     * @return un arreglo con la representación del tríangulo de pascal
     * con n niveles.
     */
    public int[][] pascal(int n) {
        int[][] arr = new int[n][n]; //guarda el arreglo que sera el triangulo de pascal
        for (int i = 0; i < n; i++) { 
            arr[i][0] = 1;
            for (int j = 1; j <= i; j++) {
                if (j == i) {
                    arr[i][j] = 1;
                } else {
                    arr[i][j] = arr[i - 1][j - 1] + arr[i - 1][j];
                }
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                if (arr[i][j] != 0) {
                    System.out.print(arr[i][j] + " "); //imprime una fila del triangulo de pascal
                }
            }
            System.out.println();
        }
        return arr;
    }


    /**
    * Muestra el arreglo de enteros.
    * @param arr1 el arreglo a mostrar
    */
    public void mostrar(int[] arr1){
        System.out.print('[');
        for (int i = 0; i < arr1.length; i++) {
            System.out.print(arr1[i]);
            if (i < arr1.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.print("]");
    }
    /**
    * Muestra la matriz de enteros.
    * @param arr2 la matriz a mostrar
    */
    public void mostrarMatriz(int[][] arr2){
         for (int i = 0; i < arr2.length; i++) {
            System.out.print("[");
            for (int j = 0; j < arr2[i].length; j++) {
                System.out.print(arr2[i][j]);
                if (j < arr2[i].length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("]");
        }
    }
}