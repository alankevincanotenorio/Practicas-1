Practica 6 - Arreglos
Profesor: Pedro Ulises Cervantes González 
Ayudante Teoria: Julio Vázquez Alvarez
Ayudante Laboratorio:
Erick Bernal Márquez 
Yessica Janeth Pablo Martinez

Equipo:
-Cano Tenorio Alan Kevin(321259967)
-Escobedo Irineo Malinalli (424121101)

¿Que nos costo mas de la practica?
Alan:La practica en general era bastante confusa para mi, ya que, se debian hacer ciclos for dentro de otros ciclos for y con diferentes condiciones, se
tenia que saber cuales eran las condiciones correctas para que poder solucionar los metodos correctamente, ademas, el metodo pascal y el metodo contiene 
fueron los mas complicados para mi, esto debido a que no sabia como realizarlo realmente.

Malinalli:En lo personal, la mayor complicacion que se me presento fue en el metodo contiene, ya que, no estaba tomando en cuenta que si un arreglo tenia 
numeros repetidos que se encuentren en otro arreglo, pues deberia arrojar false, debido a que no eran iguales, pero se pudo solucionar el problema.

Forma de trabajo:
Nuestra forma de trabajo fue mu conveniente para el poco tiempo que teniamos, ambos decidimos hacer la practica individualmente y establecimos una fecha para
mostrar nuestros resultados, unificamos nuestras ideas y metodos para que,ya en conjunto, corrigieramos errores y terminaramos la practica lo antes posible. 


Ejecucion:
Primero se descarga el archivo .tar que se subio al classroom y guardalo en la carpeta que desees
Posteriormente se descomprime el .tar
Abre la terminal y métete a la carpeta en la cual guardaste el archivo, para hacer esto escribe:

computadora:~$ cd + “nombre de la carpeta en donde se encuentran llos datos del archivo”

Posteriormente escribe el comando ls
Si te aparecen los archivos Arreglos.java, InterfazArreglos.java y readme.md estas en la carpeta correcta

En la terminal escribe javac *.java (Esto compila todos los archivos que tengas en esa carpeta)
Finalmente escribe java Arreglos en la terminal y se ejecutara la practica