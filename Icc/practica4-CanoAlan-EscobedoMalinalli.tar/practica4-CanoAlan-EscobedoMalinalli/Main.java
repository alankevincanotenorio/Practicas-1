/** Clase Principal
 * @author Alan Kevin Cano Tenorio, Malinalli Escobedo Irineo
 * @version 1.0 
 */
import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Analizador objeto =new Analizador();
        Scanner sc = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        int opcionElegida = 0;
        String menu =" \nPuedes elegir otro método \n[0] En caso de que ya no quieras usar ningun método\n[1] Encuentra vocal\n[2] Cuadrado\n[3] Rombos Numericos\n[4] Nombre Abreviado\n[5] Cuadrado con Wrappers\n[6] Rombos Numericos con Wrappers";
        
        System.out.println("¿Qué método te gustaria utilizar? Escribe el número de tu elección" );
        System.out.println("[0] En caso de que ya no quieras usar ningun método");
        System.out.println("[1] Encuentra vocal");
        System.out.println("[2] Cuadrado");
        System.out.println("[3] Rombos Numericos");
        System.out.println("[4] Nombre Abreviado");
        System.out.println("[5] Cuadrado con Wrappers");
        System.out.println("[6] Rombos Numericos con Wrappers");
        
        opcionElegida=sc.nextInt();
        while(true){
            switch(opcionElegida){
                case 0:
                    System.out.println("Fin del programa");
                    sc.close();
                    return;
                case 1:
                    System.out.println("Escribe una palabra");
                    System.out.println("La primera vocal de dicha palabra es: "+objeto.encuentraVocal(sc2.nextLine()));
                    System.out.println("Metodo finalizado");
                    System.out.println(menu);
                    break;
                case 2:
                    System.out.println("Ingresa un número, este nos dira la altura de tu cuadrado");
                    while (!sc.hasNextInt()) {
                    System.out.println("Ese no es un número. Inténtalo de nuevo:");
                    sc.next(); 
                    }
                    System.out.println("Tu cuadrado sería:");
                    objeto.cuadrado(sc.nextInt());
                    System.out.println("Metodo finalizado");
                    System.out.println(menu);
                    break;
                case 3:
                    System.out.println("Ingresa un número");
                    while (!sc.hasNextInt()) {
                        System.out.println("Ese no es un número. Inténtalo de nuevo:");
                        sc.next(); 
                        }
                    System.out.println("El rombo sería:");
                    objeto.rombosNumericos(sc.nextInt());
                    System.out.println("Metodo finalizado");
                    System.out.println(menu);                     
                    break;
                case 4: 
                    System.out.println("Ingresa el nombre que deseas abreviar");
                    System.out.println("Nombre abreviado: "+objeto.nombreAbreviado(sc2.nextLine()));
                    System.out.println("Metodo finalizado");
                    System.out.println(menu);
                    break;
                case 5:
                     System.out.println("Ingresa un número, este nos dira la altura de tu cuadrado");
                     while (!sc.hasNextInt()) {
                    System.out.println("Ese no es un número. Inténtalo de nuevo:");
                    sc.next(); 
                    }
                    System.out.println("El cuadrado se vería asi:");
                    objeto.cuadrado(sc.nextInt());
                    System.out.println("Metodo finalizado");
                    System.out.println(menu); 
                    break;
                case 6:
                    System.out.println("Ingresa un número");
                    while (!sc.hasNextInt()) {
                    System.out.println("Ese no es un número. Inténtalo de nuevo:");
                    sc.next(); 
                    }
                    System.out.println("El rombo sería:");
                    objeto.rombosNumericos(sc.nextInt());
                    System.out.println("Metodo finalizado");
                    System.out.println(menu);       
                break;
                default:
                System.out.println("No existe esa opcion, vuelve a intentarlo");
            }
            opcionElegida=sc.nextInt();
        }
   }
}