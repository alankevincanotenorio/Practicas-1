/** Clase que implementa la interfaz AnalizadorCadenas
 * @author Alan Kevin Cano Tenorio, Malinalli Escobedo Irineo
 * @version 1.0
 * 
 */
public class Analizador implements AnalizadorCadenas{
    /**
    * Metodo que regresa la primera vocal de una palabra.
    * @param palabra la cadena donde buscar la primer vocal.
    * @return regresa la primera vocal encontrada en mayusculas
    */
     public char encuentraVocal(String palabra){
         String palMayus = palabra.toUpperCase();
         char vocal=' ';
             for(int i = 0; i<palMayus.length(); i++){
             char vocalC = palMayus.charAt(i);
                if (vocalC == 'A'||vocalC == 'E'||vocalC == 'I'||vocalC == 'O'||vocalC == 'U'){
                return vocal=vocalC;
                }
             }
         return vocal;
    }

    /**
     * Metodo que realiza la figura de dos triángulos que forman a un cuadrado de asteriscos y cruces
     * @param nivel el entero que corresponde al numero de niveles comenzando desde el nivel cero
     */
    public void cuadrado(int nivel) {
        for (int i = 0; i < nivel+1; i++) {
            for (int j = 0; j < nivel - i ; j++) {
                System.out.print("+ ");
            }
            for (int k = 0; k < i + 1; k++) {
                if (k == i) {
                    System.out.print("* ");
                } else {
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
    /**
     * Metodo que realiza la estructura de rombos numéricos
     * @param n el entero que corresponde al número con el que va ascendiendo y descendiendo del rombo
     * por ejemplo si el numero es 3 , entonces se dibuja desde el primer nivel el número 1
     * en el segundo nivel la línea sería 212 y en el tercero 32123
     *       1                                      
            212                                                
           32123
            212 
             1
     */
    public void rombosNumericos(int n) {
        for (int i = 1; i <= n; i++) {
            if (n<9){
                for (int j = 0; j <n  - i; j++) {
                    System.out.print(" ");
                }
            }else{
                    if (i<9){
                        for (int j = 0; j < ((n +(n-9)) - i); j++) {
                            System.out.print(" ");
                        }
                    }else{
                        for (int j = 0; j < n - i; j++) {
                            System.out.print("  ");
                        }
                    }
                }
            for (int k = i; k >= 1; k--) {
                System.out.print(k);
            }
            for (int l = 2; l <= i; l++) {
                System.out.print(l);
            }
            System.out.println();
        }
        for (int m = n - 1; m >= 1; m--) {
            if(n<9){
                for (int p = 0; p < n  - m; p++) {
                    System.out.print(" ");
                }
            }else{
                if(m<9){
                    for (int p = 0; p < ((n +(n-9)) - m); p++) {
                    System.out.print(" ");
                    }
                }else{
                    for (int p = 0; p < n- m; p++) {
                    System.out.print("  ");
                    }
                }
            }
            for (int r = m; r >= 1; r--) {
                System.out.print(r);
            }
            for (int q = 2; q <= m; q++) {
                System.out.print(q);
            }
            System.out.println();
        }
    }



    private boolean aux(char caracter) {
        switch (caracter) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                return true;
            default:
                return false;
        }
    }
    /**
     * Metodo que recibe como entrada  el nombre completo de una persona 
     * y muestra las abreviaturas en mayúsculas del primer y segundo nombre (en caso de que tenga),
     * los apeliidos comenzarán con mayúscula y solo se concatenaran con el nombre abreviado. 
     * @param nombre el nombre completo de una persona
     * @return el nombre(s) abreviado concatenado con los apellidos (sin abreviar)
     */
    public String nombreAbreviado(String nombre){
        String nom= nombre.toUpperCase();

        int espacio1= nom.indexOf(' ')+1;
        String subNom = nom.substring(espacio1); 
        int espacio2 =subNom.indexOf(' ')+1;
        String sub2 = subNom.substring(espacio2); 
        int espacio3 =sub2.indexOf(' ');
                
            if(espacio3 == -1){
                  return nom.charAt(0) + ". "+ subNom;
            }else{
                return nom.charAt(0) + ". " + nom.charAt(espacio1)+". " + subNom.substring(espacio2); 
            }   
    }

     /**
     * Metodo que realiza la figura de dos triángulos que forman a un cuadrado de asteriscos y cruces
     * Esta implementado con wrapper
     * @param linea el entero que corresponde al numero de niveles comenzando desde el nivel cero
     */
    public void cuadradoWrapper(String num) {
        int nivel = Integer.parseInt(num);
        for (int i = 0; i < nivel+1; i++) {
            for (int j = 0; j < nivel - i ; j++) {
                System.out.print("+ ");
            }
            for (int k = 0; k < i + 1; k++) {
                if (k == i) {
                    System.out.print("* ");
                } else {
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }


    /**
     * Metodo que realiza la estructura de rombos numéricos
     * Esta implementado con wrapper
     * @param numero el entero en forma de cadena que corresponde al número con el que va ascendiendo y descendiendo del rombo
     * por ejemplo si el numero es 3 , entonces se dibuja desde el primer nivel el número 1
     * en el segundo nivel la línea sería 212 y en el tercero 32123
     *       1                                      
            212                                                
           32123
            212 
             1
     */
    public void rombosNumericosWrapper(String numero) {
        int n = Integer.parseInt(numero);
        for (int i = 1; i <= n; i++) {
            if (n<9){
                for (int j = 0; j <n  - i; j++) {
                    System.out.print(" ");
                }
            }else{
                    if (i<9){
                        for (int j = 0; j < ((n +(n-9)) - i); j++) {
                            System.out.print(" ");
                        }
                    }else{
                        for (int j = 0; j < n - i; j++) {
                            System.out.print("  ");
                        }
                    }
                }
            for (int k = i; k >= 1; k--) {
                System.out.print(k);
            }
            for (int l = 2; l <= i; l++) {
                System.out.print(l);
            }
            System.out.println();
        }

        for (int m = n - 1; m >= 1; m--) {
            if(n<9){
                for (int p = 0; p < n  - m; p++) {
                    System.out.print(" ");
                }
            }else{
                if(m<9){
                    for (int p = 0; p < ((n +(n-9)) - m); p++) {
                    System.out.print(" ");
                    }
                }else{
                    for (int p = 0; p < n- m; p++) {
                    System.out.print("  ");
                    }
                }
            }
            for (int r = m; r >= 1; r--) {
                System.out.print(r);
            }
            for (int q = 2; q <= m; q++) {
                System.out.print(q);
            }
            System.out.println();
        }
    }
}