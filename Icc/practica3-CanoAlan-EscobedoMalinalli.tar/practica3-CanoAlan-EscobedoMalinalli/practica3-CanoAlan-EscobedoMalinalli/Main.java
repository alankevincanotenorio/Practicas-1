
public class Main {
    public static void main(String[] args){
        Cadenas cadena1 = new Cadenas();
        
        String cadenaOriginal= "Hola Mundo"; 
        System.out.println("Dada la cadena: " +cadenaOriginal);
        System.out.println();

        //Vocales
        System.out.println("El numero de vocales que tiene es de: "+cadena1.vocales(cadenaOriginal));
        System.out.println();

        //Voltear cadena
        String cadenaVolteada = cadena1.reversa(cadenaOriginal);
        System.out.println("La cadena volteada sería: "+cadenaVolteada);
        System.out.println();

        //Posicion de una letra
        char letra = 'o';
        int posicionLetra =cadena1.posicion(cadenaOriginal, letra);
        System.out.println("La primer posicion del carcater '" + letra + "' en la cadena es: " +posicionLetra);
        System.out.println();

        //Es natural
        String cadenaNat = "12212";
        System.out.println("¿La cadena '" +cadenaOriginal+ "' es natural? "+cadena1.esNatural(cadenaOriginal));
        System.out.println();
        System.out.println("¿La cadena '" +cadenaNat+ "' es natural? "+cadena1.esNatural(cadenaNat));
        System.out.println();

        //Es real
        String cadenaReal = "-1.2136";
        System.out.println("¿La cadena '" +cadenaOriginal+ "' es real? "+cadena1.esReal(cadenaOriginal));
        System.out.println();
        System.out.println("¿La cadena '" +cadenaReal+ "' es real? "+cadena1.esReal(cadenaReal));
        System.out.println();

        //Cambiar
        String cambiada = cadena1.cambiar(cadenaOriginal, 'o', 'e');
        System.out.println("La cadena cambiada es " +cambiada);
        System.out.println();

        //Palindromo
        String pali = "Ana";
        boolean cadenapali =cadena1.palindromo(cadenaOriginal);
        boolean cadenapali2 =cadena1.palindromo(pali);
        System.out.println("¿La cadena '" +cadenaOriginal+ "' es un palindromo? " +cadenapali);
        System.out.println();
        System.out.println("¿La cadena '" +pali+ "' es un palindromo? " +cadenapali2);
        System.out.println();

        //Cuenta caracteres
        int vecesCaracter= cadena1.cuentaCaracter(cadenaOriginal, letra);
        System.out.println("La cantidad de veces que el caracter '" +letra+ "' aparece en la cadena '" +cadenaOriginal+ "' es de: " +vecesCaracter);
        System.out.println();

        //Subcadena
        String cadenita =cadena1.subCadena(cadenaOriginal, -6, 5);
        System.out.println("Dada la cadena '" +cadenaOriginal+ "' una subcadena de esta sera: " +cadenita);
        System.out.println();

        //Numero primo
        int x = -2;
        int x2 = 2;
        boolean primo =cadena1.esPrimo(x);
        boolean primo2 =cadena1.esPrimo(x2);
        System.out.println("¿El numero " +x+ " es primo? " +primo);
        System.out.println();
        System.out.println("¿El numero " +x2+ " es primo? " +primo2);
        System.out.println();

        //Suma digitos
        int numero = 1234567890;
        System.out.println("Dado el numero: " +numero);
        System.out.println();
        System.out.println("la suma de sus digitos es de: "+cadena1.sumaDigitos(numero));
        System.out.println();

        //Cuenta palabras
        int numPalabras = cadena1.cuentaPalabras(cadenaOriginal);
        System.out.println("¿Cuantas palabras hay en la cadena '"+ cadenaOriginal + "' ? Hay " +numPalabras+" palabras");
        System.out.println();

     }
    
}
