/** Clase Cadenas que implementa la interfaz Metodos
 * Se desarrollan los metodos incluidos en la interfaz
 * @author Alan Kevin Cano Tenorio, Malinalli Escobedo Irineo
 * @version 1.0
 */

public class Cadenas implements Metodos{

    //Recuerda que puedes agregar los metodos auxilaires que quieras
    //pero no puedes modificar los que ya están aquí

    //Los puntos se evaluan sobre 80% de la calificacion

    /**
     * Dada una cadena, nos regresa el numero de vocales que contiene
     * Sin importar si son mayusculas o minusculas
     * @param cadena la cadena a analizar
     * @return el numero de vocales que contiene la cadena
     */
    public int vocales(String cadena){ //1 punto
        int bandera1 = 0;
        for (int i = 0; i<cadena.length(); i++){
            char vocales = cadena.charAt(i);
            switch (vocales){
                case 'a':
                bandera1++;
                break;
                case 'e':
                bandera1++;
                break;
                case 'i':
                bandera1++;
                break;
                case 'o':
                bandera1++;
                break;
                case 'u':
                bandera1++;
                break;
                case 'A':
                bandera1++;
                break;
                case 'E':
                bandera1++;
                break;
                case 'I':
                bandera1++;
                break;
                case 'O':
                bandera1++;
                break;
                case 'U':
                bandera1++;
                break;
                default:
            }
        }
     return bandera1;
    }


    /**
     * Regresa la cadena en reversa
     * @param cadena la cadena a revertir
     * @return la cadena revertida
     */
    public String reversa(String cadena){ //1 punto
        String cadena2 ="";
        int indice = cadena.length()-1;
        while(indice>=0){
            cadena2+="" + cadena.charAt(indice);
            indice--;
        }
            return cadena2;
    }

     /**
     * Nos regresa la posición de la primera ocurrencia 
     * del caracter en la cadena
     * Hace distinción entre mayusculas y minusculas
     * @param cadena la cadena a analizar
     * @param caracter el caracter a buscar
     * @return la posición del caracter en la cadena
     *        -1 si no se encuentra
     */
    public int posicion(String cadena, char caracter){  //1 punto
        int pos = 0;
        for(int i = 0; i<cadena.length(); i++){
        char posi = cadena.charAt(i);
        if (posi != caracter){
                pos = -1;
            } else {
                return i;
            }
         }
            return pos;
    }
    

    /**
     * Determina si la cadena es un numero natural
     * @param cadena la cadena a analizar
     * @return true si es un numero natural, false en otro caso
     */
    public boolean esNatural(String cadena){//0.4 puntos
        boolean bandera = false;

        for (int i = 0; i<cadena.length(); i++){
            char ver = cadena.charAt(i);
            switch (ver){
                case '0':
                bandera = true;
                break;
                case '1':
                bandera = true;
                break;
                case '2':
                bandera = true;
                break;
                case '3':
                bandera = true;
                break;
                case '4':
                bandera = true;
                break;
                case '5':
                bandera = true;
                break;
                case '6':
                bandera = true;
                break;
                case '7':
                bandera = true;
                break;
                case '8':
                bandera = true;
                break;
                case '9':
                bandera = true;
                break;
                case '-':
                bandera = false;
                return bandera;
                case '.':
                bandera = false;
                return bandera;
                default:
                bandera = false;
                return bandera;
            }
        }
    return bandera;
    }


    /**
     * Determina si la cadena es un numero entero
     * @param cadena la cadena a analizar
     * @return true si es un numero entero, false en otro caso
     */
    public boolean esReal(String cadena){ //0.6 puntos
        boolean bandera = false;
        for (int i = 0; i<cadena.length(); i++){
            char verificar = cadena.charAt(i);
            switch (verificar){
                case '1':
                bandera = true;
                break;
                case '2':
                bandera = true;
                break;
                case '3':
                bandera = true;
                break;
                case '4':
                bandera = true;
                break;
                case '5':
                bandera = true;
                break;
                case '6':
                bandera = true;
                break;
                case '7':
                bandera = true;
                break;
                case '8':
                bandera = true;
                break;
                case '9':
                bandera = true;
                break;
                case '0':
                bandera = true;
                break;
                case '-':
                if((cuentaCaracter(cadena, verificar)) < 2){
                    bandera = true;
                }else{
                    return bandera = false;
                }                break;
                case '.':
                if((cuentaCaracter(cadena, verificar)) < 2){
                    bandera = true;
                }else{
                    return bandera = false;
                }
                break;
                default:
                bandera = false;
                return bandera;
            }
        }
    return bandera;
    }

    /**
     * Reeplaza todas las ocurrencias de un caracter por otro
     * Hace distinción entre mayusculas y minusculas
     * @param cadena la cadena a analizar
     * @param cambiar el caracter viejo que va a ser cambiado
     * @param nuevo el caracter nuevo que va a reemplazar al viejo
     * @return la cadena con los cambios realizados
     */
    public String cambiar(String cadena, char cambiar, char nuevo){ //1 punto
    String cadenanueva = "";
    for(int i = 0; i<cadena.length(); i++){
    char cambio = cadena.charAt(i);
        if(cambio == cambiar){
           cadenanueva += nuevo;
        } else{
            cadenanueva += cambio;
        }
    }
    return cadenanueva;

    }
     /**
     * Determina si la cadena es un palindromo
     * No toma en cuenta lo espacios en blanco
     * No hace distinción entre mayusculas y minusculas
     * @param cadena la cadena a analizar
     * @return true si es un palindromo, false en otro caso
     * */
    public boolean palindromo(String cadena){ //1 punto
        Cadenas objeto = new Cadenas();
        String cadenaNueva = objeto.reversa(cadena);
        cadenaNueva = cadenaNueva.toUpperCase();
        cadena= cadena.toUpperCase();
        boolean palin= (cadenaNueva.equals(cadena)) ? true : false;
        return palin;
    }
    
   
    /**
     * Cuanta el numero de ocurrencias de un caracter en la cadena
     * Hace distinción entre mayusculas y minusculas
     * @param cadena la cadena a analizar
     * @param caracter el caracter a buscar
     * @return el numero de ocurrencias del caracter en la cadena
     */
    public int cuentaCaracter(String cadena, char caracter){ //1 punto
        int i=0;
        int indice = cadena.length()-1;
        while(indice>=0){
            char letra = cadena.charAt(indice);
            indice--;
            if (caracter == letra){
                i++;
            }
        }
        return i;
    }

    /**
     * Dada una cadena nos regresa una subcadena 
     * @param cadena la cadena a analizar
     * @param inicio el índice donde inicia la subcadena. Este es inclusivo
     * @param fin el índice donde termina la subcadena. Este es exclusivo
     * @return
     */
    public String subCadena(String cadena, int inicio, int fin){ //1 punto
        Cadenas objetoPrueba =new Cadenas();
        if (inicio>=0){
            return objetoPrueba.aux(cadena, inicio);
        }else{
            return objetoPrueba.aux(cadena, fin);
        }
    }

    /**
     * Metodo auxiliar para el metodo de subCadena
     * @param cadena la cadena a analizar
     * @param valor el indice donde inicia la subcadena. Es inclusivo
     * @return
     */
    private String aux(String cadena, int valor){
        String nuevaCadena = "";
        int limite = cadena.length()-1;
            for(int i=valor; i<=limite; i++){
                nuevaCadena +=cadena.charAt(i);
            }return nuevaCadena;
    }

    /**
     * Determina si un numero es primo
     * @param numero el numero a analizar
     * @return true si es primo, false en otro caso
     */
    public boolean esPrimo(int numero){ //1 punto
        if(numero==2 || numero==3 || numero==5 ){
            return true;
        }else if(numero%2 == 0 || numero%3 ==0 || numero%5==0 || numero==1 || numero<0){
             return false;
        }else{
            return true;
        }
    }


    /**
     * Hace la suma de los digitos de un numero
     * @param numero el numero a analizar
     * @return la suma de los digitos del numero
     */
    public int sumaDigitos(int numero) {  //1 punto
        int suma = 0;
        if(numero < 0){
            numero *= -1;
        }
        String nume = String.valueOf(numero);
        for (int i = 0; i < nume.length(); i++) {
            char n = nume.charAt(i);
            int digito = Integer.parseInt(String.valueOf(n));
            suma += digito;
        }
        return suma;
    }

    /********************EXTRA********************/
    /**
     * Cuenta la cantidad de palabras que hay en una cadena
     * Para ello no usaremos el metodo split, ni arreglos
     * @param cadena la cadena a analizar
     * @return el numero de palabras que hay en la cadena
     */
    public int cuentaPalabras(String cadena){
        //1 punto extra sobre el 80%
        String cadenaVacia1 = "";
        String cadenaVacia2 = " ";
        String cadenaVacia3 = "  ";
        if(cadena.equals(cadenaVacia1)){
        return 0;
        }else if(cadena.equals(cadenaVacia2)){
            return 0;
        }
        else if(cadena.equals(cadenaVacia3)){
            return 0;
        }else{
        Cadenas objetoxd = new Cadenas();
        int posicioon= objetoxd.cuentaCaracter(cadena, ' ');
        return ++posicioon;
        }
    }
}



    

