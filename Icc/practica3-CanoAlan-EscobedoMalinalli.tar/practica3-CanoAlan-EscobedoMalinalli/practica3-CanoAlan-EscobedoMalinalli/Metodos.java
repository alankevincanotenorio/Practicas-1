
    public interface Metodos {

        //Recuerda que puedes agregar los metodos auxilaires que quieras
        //pero no puedes modificar los que ya están aquí
    
        //Los puntos se evaluan sobre 80% de la calificacion
    
        /**
         * Dada una cadena, nos regresa el numero de vocales que contiene
         * Sin importar si son mayusculas o minusculas
         * @param cadena la cadena a analizar
         * @return el numero de vocales que contiene la cadena
         */
        public int vocales(String cadena); //1 punto
    
        /**
         * Regresa la cadena en reversa
         * @param cadena la cadena a revertir
         * @return la cadena revertida
         */
        public String reversa(String cadena); //1 punto
    
        /**
         * Nos regresa la posición de la primera ocurrencia 
         * del caracter en la cadena
         * Hace distinción entre mayusculas y minusculas
         * @param cadena la cadena a analizar
         * @param caracter el caracter a buscar
         * @return la posición del caracter en la cadena
         *        -1 si no se encuentra
         */
        public int posicion(String cadena, char caracter); //1 punto
        
        /**
         * Determina si la cadena es un numero natural
         * @param cadena la cadena a analizar
         * @return true si es un numero natural, false en otro caso
         */
        public boolean esNatural(String cadena); //0.4 puntos
        
        /**
         * Determina si la cadena es un numero entero
         * @param cadena la cadena a analizar
         * @return true si es un numero entero, false en otro caso
         */
        public boolean esReal(String cadena); //0.6 puntos
        
        /**
         * Reeplaza todas las ocurrencias de un caracter por otro
         * Hace distinción entre mayusculas y minusculas
         * @param cadena la cadena a analizar
         * @param cambiar el caracter viejo que va a ser cambiado
         * @param nuevo el caracter nuevo que va a reemplazar al viejo
         * @return la cadena con los cambios realizados
         */
        public String cambiar(String cadena, char cambiar, char nuevo); //1 punto
        
        /**
         * Determina si la cadena es un palindromo
         * No toma en cuenta lo espacios en blanco
         * No hace distinción entre mayusculas y minusculas
         * @param cadena la cadena a analizar
         * @return true si es un palindromo, false en otro caso
         */
        public boolean palindromo(String cadena); //1 punto
        
        /**
         * Cuanta el numero de ocurrencias de un caracter en la cadena
         * Hace distinción entre mayusculas y minusculas
         * @param cadena la cadena a analizar
         * @param caracter el caracter a buscar
         * @return el numero de ocurrencias del caracter en la cadena
         */
        public int cuentaCaracter(String cadena, char caracter); //1 punto
        
        /**
         * Dada una cadena nos regresa una subcadena 
         * @param cadena la cadena a analizar
         * @param inicio el índice donde inicia la subcadena. Este es inclusivo
         * @param fin el índice donde termina la subcadena. Este es exclusivo
         * @return
         */
        public String subCadena(String cadena, int inicio, int fin); //1 punto
        
        /**
         * Determina si un numero es primo
         * @param numero el numero a analizar
         * @return true si es primo, false en otro caso
         */
        public boolean esPrimo(int numero); //1 punto
    
    
        /**
         * Hace la suma de los digitos de un numero
         * @param numero el numero a analizar
         * @return la suma de los digitos del numero
         */
        public int sumaDigitos(int numero); //1 punto
    
    
        /********************EXTRA********************/
        /**
         * Cuenta la cantidad de palabras que hay en una cadena
         * Para ello no usaremos el metodo split, ni arreglos
         * @param cadena la cadena a analizar
         * @return el numero de palabras que hay en la cadena
         */
        public int cuentaPalabras(String cadena); 
        //1 punto extra sobre el 80%
    
}
