 public class Pato{
 
    // Atributos
    private String nombre;
    private int edad;
    private String color;
    private int plumas;
    private static int pico = 1;

    // Constructores
   
    public Pato(String nombre, int edad, String color) {
        this.nombre = nombre;
        this.edad = edad;
        this.color = color;
        }

    public Pato(String nombre, int plumas) {
        this.nombre = nombre;
        this.plumas = plumas;   
    }


    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPlumas() {
        return plumas;
    }

    public void setplumas(int plumas) {
        this.plumas = plumas;
    }

    public static int getPico() {
        return pico;
    }

    // Métodos
    public void graznar() {
        System.out.println(nombre + " esta graznando ('Cuack')");
    }

    public void comer() {
        System.out.println(nombre + " esta comiendo pan");
    }

    public void correr() {
        System.out.println(nombre + " esta corriendo hacia su dueño");
    }

     public void nadar() {
        System.out.println(nombre + " esta nadando en la alberca");
    }

    public void aletear() {
        System.out.println(nombre + " esta aleteando para llamar la atencion");
    }


 public String toString() {
         return "nombre: " + nombre+
         "\nEdad:"+edad+
         "\nColor: "+color+
         "\nPlumas: "+plumas+
         "\nNumero de Picos: "+pico;        
        
    }
}