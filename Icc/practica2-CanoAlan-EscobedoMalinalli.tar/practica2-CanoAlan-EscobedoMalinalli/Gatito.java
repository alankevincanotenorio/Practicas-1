/**
 * Representa la clase Gatito
 * la cual implementa la interaz InterfazGatito
 */
public class Gatito{
    private String nombre;
    private int edad;
    private int energia;
    private boolean vacunado;
    private Juguete juguete;

    /**
     * Completa el metodo constructor
     * con los atributos de nombre y edad
     * @param nombre el nombre del gatito
     * @param edad la edad del gatito
     */
    public Gatito(String nombre, int edad){
        //Aquí va tu código
        this.nombre = nombre;
        this.edad = edad;
        this.energia = 100;
        this.vacunado = false;
        this.juguete = null;
    }

    /**
     * Agrega los métodos getters y setters 
     * de todos los atributos de la clase Gatito
     * nombre, edad, energia, vacunado y juguete
     */
    public String getNombre(){
        return nombre;
    }
    public int getEdad(){
        return edad;
    }
    public int getEnergia(){
        return energia;
    }
    public boolean getVacunado(){
        return vacunado;
    }
    /**
     * Regresa el juguete del gatito
     * @return el juguete del gatito
     */ 
    public Juguete getJuguete(){
        return juguete;
    }


     public void setNombre(String nombre){
        this.nombre = nombre;
    }

     public void setEdad(int edad){
        this.edad = edad;
    }

     public void setEnergia(int energia){
        this.energia = energia;
    }

     public void setVacunado(boolean vacunado){
        this.vacunado = vacunado;
    }
    /**
     * Cambia el juguete del gatito
     * @param juguete el nuevo juguete del gatito
     */
    public void setJuguete(Juguete juguete){
        this.juguete = juguete;
    }

    /** 
     * Hace que el gatito maulle gastando 10 puntos de energia
     * @return el maullido del gatito
     */
    public String maullar(){
        // Aqui va tu codigo
        energia = energia - 10;
        return "Miau";
    }


    /**
     * Hace al gatito jugar con el juguete gastando 20 puntos de energia
     * Ademas desgasta el juguete que tenga con un metodo apropiado para desgastar un juguete
     * @return algun mensaje de que el gatito juega con el juguete
     */
    public String jugar(){
        //Aqui va tu codigo
        this.juguete.desgastar();
        energia = energia - 20;
        return "El gato esta jugando";
    }
       
    /**
     * Hace que el gatito escale gastando 30 puntos de energia
     * @return un mensaje de confirmacion de que el gatito ha escalado
     */
    public String escalar() {
        //Aqui va tu codigo
        energia = energia - 30;
        return "El gato se canso escalando";
    }

    /**
     * Hace que el gatito descanse recuperando 40 puntos de energia
     * @return un mensaje de confirmacion de que el gatito ha descansado
     */
    public String descansar(){
        //Aqui va tu codigo
        energia = energia + 40;
        return "El gatito está mimiendo";
    }

    /**
     * Representacion en cadena de la clase Perrito
     */
    public String toString(){
        return nombre+
        ",\tEdad: "+edad+
        ",\tEnergia: "+energia+
        ",\tVacunado: "+vacunado+
        ",\tJuguete: "+juguete;
    }
    
}