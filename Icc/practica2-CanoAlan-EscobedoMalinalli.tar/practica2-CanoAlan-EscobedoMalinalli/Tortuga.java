public class Tortuga{
    
    
    // atributos
    private String nombre;
    private int edad;
    private double peso;
    private static int numeroDeTortugas = 2;
    private String colorTortuga;
    



    // constructores
   
    public Tortuga(String nombre, int edad, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        }
  

    public Tortuga(String nombre, String colorTortuga) {
        this.nombre = nombre;
        this.colorTortuga = colorTortuga;
    }




    // getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public static int getNumeroDeTortugas() {
        return numeroDeTortugas;
    }

    public String getColorTortuga() {
        return colorTortuga;
    }

    public void setColorTortuga(String colorTortuga) {
        this.colorTortuga = colorTortuga;
    }




    // metodos
    public void comer() {
        System.out.println(nombre + " esta comiendo");
    }

    public void dormir() {
        System.out.println(nombre + " esta durmiendo");
    }

    public void nadar() {
        System.out.println(nombre + " esta nadando");
    }

     public void bailar() {
        System.out.println(nombre + " esta bailando");
    }

    public void sonreir() {
        System.out.println(nombre + " esta happy");
    }


 public String toString() {
         return "nombre:" + nombre+ ",edad:" + edad+ ",color:" +colorTortuga+ ",peso:" +peso;
    }

    

    
   
        

        

       


}