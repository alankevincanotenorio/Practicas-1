public class Main {
  public static void main(String[] args) {
    
    //Persona que tiene 50 ajolopesos y no tiene Perrito o Gatito
    Persona juan = new Persona("Juan", 25, 50);

    //Perrito de nombre samy
    Perrito samy = new Perrito("Samy", 7);

    //Persona que solo tiene un perrito, para ello previamente se hizo el perrito
    Persona tanis = new Persona("Tania", 25, 100, samy);

    //Gatito de nombre aceituno
    Gatito aceituno =  new Gatito("Aceituno", 10);

    //Persona que solo tiene un gatito, para ello previamente se hizo el gatito
    //ademas no tiene dinero :(
    Persona diana = new Persona("Diana", 25, 0, aceituno);

    //Perrito y gatito
    Perrito firulais = new Perrito("Blanquita", 15);
    Gatito naranjo  = new Gatito("Naranajo", 8);


    //Persona que tiene perrito y gatito, para ello previamente se hicieron 
    //el perrito y gatito
    Persona rubi = new Persona("Rubi", 25, 200, firulais, naranjo);
        
    /** Aqui podemos ver las personas con sus respectivos 
     * perritos y gatitos
     */
    System.out.println(juan);
    System.out.println("\n");
    System.out.println(tanis);
    System.out.println("\n");
    System.out.println(diana);
    System.out.println("\n");
    System.out.println(rubi);


    //Crea y asigna y nuevo perrito para juan
    Perrito perritoJuan = new Perrito("Juanito", 2);
    juan.setPerrito(perritoJuan);



    //muestra que juan tiene un nuevo perrito
    System.out.println("\n");
    System.out.println(juan);

    
    //crea y asigna un nuevo gatito para juan
    Gatito gatitoJuan = new Gatito("Gomita", 3);
    juan.setGatito(gatitoJuan);



    
    //muestra que juan tiene un nuevo gatito
    System.out.println("\n");
    System.out.println(juan);




    //vacuna al perrito de Tanis y al gatito de Diana 
     tanis.vacunarPerrito();
     diana.vacunarGatito();





    //muestra que el perrito de Tanis y el gatito de Diana estan vacunados

    System.out.println("\n");
    System.out.println(tanis);
    System.out.println("\n");
    System.out.println(diana);



    //haz que Diana, Tanis y Rubi chambeen
    diana.chambear();
    rubi.chambear();
    tanis.chambear();





    // Muestra que Diana, Tanis y Rubi generaron dinero gracias a la chamba
    System.out.println("\n");
    System.out.println(tanis);
    System.out.println("\n");
    System.out.println(diana);
    System.out.println("\n");
    System.out.println(rubi);









    // Crea al menos 3 juguetes diferentes
      Juguete juguete1 = new Juguete("pelota", 10);
      Juguete juguete2 = new Juguete("hueso", 5);
      Juguete juguete3 = new Juguete("peluche", 15);



    // (Estos se mostraran de manera automatica)





    // asigna el primer juguete al perrito de juan
    // el segundo juguete al perrito de Tanis
    //el tercer juguete al gatito de rubi

    juan.comprarJuguetePerrito(juguete1);
    tanis.comprarJuguetePerrito(juguete2);
    rubi.comprarJugueteGatito(juguete3);






    // Muestra que Juan, Tanis y Rubi tienen un juguete para su perrito y gatito
    System.out.println("\n");
    System.out.println(juan);
    System.out.println("\n");
    System.out.println(tanis);
    System.out.println("\n");
    System.out.println(rubi);
      







    // Haz que el gatito de Diana y el perrito de Rubi jueguen con su juguete
      //se crearon dos juguetes para el gatito de Diana y perrito de Rubi debido a que no existian para ninguno de los dos  
      Juguete juguete4 = new Juguete("zapato", 7);
      Juguete juguete5 = new Juguete("cuerda", 6);

      //se les asigna un juguete a cada uno para que puedan jugar con el
      rubi.comprarJuguetePerrito(juguete4);
      diana.comprarJugueteGatito(juguete5);

      aceituno.jugar();
      firulais.jugar();


    //Muestra los cambios de energia de los perritos y gatitos de Diana y Rubi
    System.out.println("\n");
    System.out.println(rubi);
    System.out.println("\n");
    System.out.println(diana);




    // !----- en caso de tener clases extra, puedes probarlas aqui-----!
    // Crea un objeto por cada clase que tengas
    Pato pato1 = new Pato("Charles", 1, "blanco");
    Pato pato2 = new Pato("Charlie", 50 );

    Tortuga tortuga1  = new Tortuga ("Donatelo", 2, 1.5);    
    Tortuga tortuga2 = new Tortuga("Rafael", "verde");
    


    System.out.println(pato1);
    System.out.println("\n");
    System.out.println(pato2);
    System.out.println("\n");
    System.out.println(tortuga1);
    System.out.println("\n");
    System.out.println(tortuga2);
  }
}