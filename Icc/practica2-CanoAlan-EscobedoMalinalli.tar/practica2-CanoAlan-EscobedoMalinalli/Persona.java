/**
 * Representa una clase Persona
 * Tiene multiples metodos constructores asi como los
 * getters y setters
 */
public class Persona {
    private String nombre;
    private int edad;
    private int ajolopesos;
    private Perrito perrito;
    private Gatito gatito;

    /**
     * Completa los metodos constructores de acuerdo a lo pedido
     */


    /**
     * @param nombre el nombre de la persona
     * @param edad la edad de la persona
     * @param ajolopesos la cantidad de ajolopesos de la persona.
     */
    public Persona(String nombre, int edad, int ajolopesos){
        this.nombre = nombre;
        this.edad = edad;
        this.ajolopesos = ajolopesos;
    }   

    /**
     * Completa el metodo constructor donde solo reciba un perrito
     * pero no un gatito
     * @param nombre el nombre de la persona
     * @param edad la edad de la persona
     * @param ajolopesos la cantidad de ajolopesos de la persona.
     * @param perrito el perrito de la persona
     */
    public Persona(String nombre, int edad, int ajolopesos, 
                   Perrito perrito){
        //Aqui va tu codigo
        this.nombre = nombre;
        this.edad = edad;
        this.ajolopesos = ajolopesos;
        this.perrito = perrito;
    }

    /**
     * Completa el metodo constructor donde solo reciba un gatito
     * pero no un perrito
     * @param nombre el nombre de la persona
     * @param edad la edad de la persona
     * @param ajolopesos la cantidad de ajolopesos de la persona.
     * @param gatito el gatito de la persona
     */
    public Persona(String nombre, int edad, int ajolopesos, 
                   Gatito gatito){
        //Aqui va tu codigo
        this.nombre = nombre;
        this.edad = edad;
        this.ajolopesos = ajolopesos;
        this.gatito = gatito;
    }

    /**
     * @param nombre el nombre de la persona
     * @param edad la edad de la persona
     * @param ajolopesos la cantidad de ajolopesos de la persona. 
     * @param perrito el perrito de la persona
     * @param gatito el gatito de la person
     */
    public Persona(String nombre, int edad, int ajolopesos, Perrito perrito, Gatito gatito){
        //Aqui va tu codigo
        this.nombre = nombre;
        this.edad = edad;
        this.ajolopesos = ajolopesos;
        this.perrito = perrito;
        this.gatito = gatito;
    }


    /**
     * Agrega los metodos getters y setters 
     * de todos los atributos de la clase Persona
     * nombre, edad, dinero, perrito y gatito
     */

    /**
     * Regresa el nombre de la persona
     * @return el nombre de la persona
     */
    public String getNombre(){
        return this.nombre;
    }
    public int getEdad(){
        return edad;
    }
    public int getAjolopesos(){
        return ajolopesos;
    }
    public Perrito getPerrito(){
        return perrito;
    }
    public Gatito getGatito(){
        return gatito;
    }

    /**
     * Cambia el nombre de la persona
     * @param nombre el nuevo nombre de la persona
     */
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
     public void setEdad(int edad){
        this.edad = edad;
    }
     public void setAjolopesos(int ajolopesos){
        this.ajolopesos = ajolopesos;
    }
     public void setPerrito(Perrito perrito){
        this.perrito = perrito;
    }
    public void setGatito(Gatito gatito){
        this.gatito = gatito;
    }


    /**
     * Recibe un perrito para adoptarlo
     * @param perrillo el perrito a adoptar
     * @return un mensaje de confirmacion de la adopcion del perrito
     */
    public String adoptarPerrito(Perrito perrillo){
        this.perrito = perrillo;
        return "Perrito adoptado!";
    }


    /**
     * Recibe un gatito para adoptarlo
     * @param gatillo el gatito a adoptar
     * @return un mensaje de confirmacion de la adopcion del gatito
     */
    public String adoptarGatito(Gatito gatillo){
        //aqui va tu codigo
        this.gatito = gatillo;
        return "Gatito adoptado!";
    }

    /**
     * Pone a la persona a trabajar y gana 30 ajolopesos
     * @return un mensaje de confirmacion de la chamba
     */
    public String chambear(){
        ajolopesos = ajolopesos+30;
        return "Si se sabe la de chambear";
    }

    /**
     * La persona se pone a gastar y le resta 50 ajolopesos
     * @return un mensaje de confirmacion de lo gastado
     */
    public String gastar(){
        //Aqui va tu codigo
        ajolopesos = ajolopesos-50;
        return "No se sabe la de ahorrar";
    }

    /**
     * Compra un juguete para el perrito y lo agrega a su atributo
     * @param juguete el nuevo juguete del perrito
     * No olvides restar el precio del juguete a los ajolopesos de la persona
     * Utiliza juguete.getPrecio() para saber la cantidad a restar
     * Y setJuguete() para cambiar el juguete del perrito
     * @return un mensaje de confirmacion de la compra
     */
    public String comprarJuguetePerrito(Juguete nuevo){
        //Se va a explicar en clase
        int precio = nuevo.getPrecio();//obtenemos el precio
        this.ajolopesos = ajolopesos - precio;//restamos el precio
        this.perrito.setJuguete(nuevo);//cambiamos el juguete
        return "juguete comprado para el perrito";
    }

    /**
     * Compra un juguete para el gatito y lo agrega a su atributo
     * @param juguete el nuevo juguete del gatito
     * No olvides restar el precio del juguete a los ajolopesos de la persona
     * Utiliza juguete.getPrecio() para saber la cantidad a restar
     * Y setJuguete() para cambiar el juguete del gatito
     * @return un mensaje de confirmacion de la compra
     */
    public String comprarJugueteGatito(Juguete nuevo){
        //aqui va tu codigo

        int precio = nuevo.getPrecio();//obtenemos el precio
        this.ajolopesos = ajolopesos - precio;//restamos el precio
        this.gatito.setJuguete(nuevo);//cambiamos el juguete
        return "juguete comprado para el gatito";
    }

    /**
     * Repara el juguete del perrito
     * @return un mensaje de confirmacion de la reparacion del juguete
     */
    public String repararJuguetePerrito(){
        //aqui va tu codigo
        //Pista: obten el juguete del perrito con get y usa el metodo reparar
        Juguete juguete2 = perrito.getJuguete();
        juguete2.reparar();
        return "El hueso ha sido reparado";
    }

    /**
     * Repara el juguete del gatito
     * @return un mensaje de confirmacion de la reparacion del juguete
     */
    public String repararJugueteGatito(){
        //aqui va tu codigo
        Juguete juguete1 = gatito.getJuguete();
        juguete1.reparar();
        return "La pelota ha sido reparada";
    }

    /**
     * Vacuna al perrito
     * Cambia el atributo de vacunado del perrito con setVacunado(true)
     * El precio de la vacuna es de 75 ajolopesos
     * No olvides restar el precio de la vacuna a los ajolopesos
     * @return un mensaje de confirmacion de la vacuna del perrito
     */
    public String vacunarPerrito(){
        //aqui va tu codigo
        int vacuna = 75;
        this.ajolopesos-=75;//se le resta
        this.perrito.setVacunado(true);
        return "el perro ha sido vacunado" +perrito.getNombre();
    }

    /**
     * Vacuna al gatito
     * Cambia el atributo de vacunado del gatito con setVacunado(true)
     * El precio de la vacuna es de 75 ajolopesos
     * No olvides restar el precio de la vacuna a los ajolopesos
     * @return un mensaje de confirmacion de la vacuna del gatito
     */
    public String vacunarGatito(){
        //aqui va tu codigo

        int vacuna = 75;
        this.ajolopesos-=75;//se le resta
        this.gatito.setVacunado(true);
        return "el gato ha sido vacunado" +gatito.getNombre();
    }

    
    /**
     * Representacion en cadena de la clase Persona
     */
    public String toString(){
        return "Nombre: "+nombre+
                "\nEdad: "+edad+
                "\nAjolopesos: "+ajolopesos+
                "\nPerrito: "+perrito+
                "\nGatito: "+gatito;
    }
    
}